import requests
import bs4
from flask import Flask,render_template, request, redirect, url_for, Response , jsonify
app = Flask(__name__)
@app.route('/',methods = ["GET","POST"])



def index():
    ans=[]
    dic={}
    temp = "wikipedia.org"
    if(request.method == "POST"):
        data = request.form.get("url")
        try:
            result = requests.get(data)
            if temp in data:
                soup = bs4.BeautifulSoup(result.text,"lxml")
                list = soup.select('html')
                ss=""
                for i in list:
                    ss+=i.text
                    ss+=" "

                s=""
                for i in range (0,len(ss)):
                    if (ss[i]>='a' and ss[i]<='z') or (ss[i]>='A' and ss[i]<='Z') or ss[i]==" ":
                        s+=ss[i]
                    else:
                        s+=" "
                
                l=s.split()
                for i in range(0,len(l)):
                    if l[i] in dic:
                        dic[l[i]]+=1
                    else:
                        dic[l[i]]=1
                
                for i in range(0,10):
                    max_key = max(dic, key=dic.get)
                    myset = (max_key,dic[max_key])
                    ans.append(myset)
                    dic.pop(max_key)
            else:
                ans = "URL not of Wikipedia"
                return render_template("index.html", ans=ans)
        except:
            ans = "URL does not exist on Internet"
    return render_template("index.html", ans=ans)
        

